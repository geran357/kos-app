import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css"; // Import styling umum jika diperlukan

// Temukan elemen root di dalam index.html
const root = ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
);

// Render komponen App ke dalam root
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
