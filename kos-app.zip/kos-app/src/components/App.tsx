import ListGroup from "./Index";

function App() {
  return (
    <div>
      <ListGroup />
    </div>
  );
}

export default App;
